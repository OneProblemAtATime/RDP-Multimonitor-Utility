while True:
    if x == None:
        x = 0
    else:
        x+=1
    print(x)
    if x > 4:
        break
    else:
        pass

for i in range(3):
    print(i)
